import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import Header from '../components/Header.jsx';
import useUserStore from '../store/userStore';
import { registerMember } from '../api/memberApi';

function Register() {
  const navigate = useNavigate();
  const { checkUserIdExists, checkEmailExists } = useUserStore();
  
  const [formData, setFormData] = useState({
    name: '',
    userId: '',
    email: '',
    password: '',
    passwordConfirm: ''
  });

  const [errors, setErrors] = useState({});

  // TanStack Query Mutation
  const registerMutation = useMutation({
    mutationFn: registerMember,
    onSuccess: (data) => {
      alert(`회원가입이 완료되었습니다!\n이름: ${formData.name}\n아이디: ${formData.userId}\n이메일: ${formData.email}`);
      navigate('/login');
    },
    onError: (error) => {
      if (error.response) {
        // 서버에서 반환한 에러 메시지 처리
        const errorMessage = error.response.data?.message || error.response.data?.error || '회원가입에 실패했습니다.';
        alert(errorMessage);
      } else if (error.request) {
        // 요청은 보냈지만 응답을 받지 못한 경우
        alert('서버에 연결할 수 없습니다. 서버가 실행 중인지 확인해주세요.');
      } else {
        // 요청 설정 중 에러 발생
        alert('회원가입 요청 중 오류가 발생했습니다.');
      }
    },
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // 에러 초기화
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = '이름을 입력하세요.';
    }

    if (!formData.userId.trim()) {
      newErrors.userId = '아이디를 입력하세요.';
    } else if (checkUserIdExists(formData.userId)) {
      newErrors.userId = '이미 사용 중인 아이디입니다.';
    }

    if (!formData.email.trim()) {
      newErrors.email = '이메일을 입력하세요.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식이 아닙니다.';
    } else if (checkEmailExists(formData.email)) {
      newErrors.email = '이미 사용 중인 이메일입니다.';
    }

    if (!formData.password) {
      newErrors.password = '비밀번호를 입력하세요.';
    } else if (formData.password.length < 6) {
      newErrors.password = '비밀번호는 최소 6자 이상이어야 합니다.';
    }

    if (!formData.passwordConfirm) {
      newErrors.passwordConfirm = '비밀번호 확인을 입력하세요.';
    } else if (formData.password !== formData.passwordConfirm) {
      newErrors.passwordConfirm = '비밀번호가 일치하지 않습니다.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleRegister = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    // 백엔드 DTO에 맞게 작성
    const registerData = {
      userId: formData.userId.trim(),
      userName: formData.name.trim(),
      email: formData.email.trim(),
      password: formData.password,
      passwordCheck: formData.passwordConfirm,
    };

    // TanStack Query Mutation 실행
    registerMutation.mutate(registerData);
  };

  return (
    <>
      <Header />
      <div className="container">
        <div className="form-card">
          <h2>회원가입</h2>
          <form onSubmit={handleRegister}>
            <div className="form-group">
              <label>이름</label>
              <input 
                type="text" 
                name="name"
                placeholder="이름을 입력하세요" 
                value={formData.name}
                onChange={handleChange}
                required 
              />
              {errors.name && <span style={{color: 'var(--error)', fontSize: '0.85rem', marginTop: '0.25rem', display: 'block'}}>{errors.name}</span>}
            </div>
            <div className="form-group">
              <label>아이디</label>
              <input 
                type="text" 
                name="userId"
                placeholder="사용할 아이디를 입력하세요" 
                value={formData.userId}
                onChange={handleChange}
                required 
              />
              {errors.userId && <span style={{color: 'var(--error)', fontSize: '0.85rem', marginTop: '0.25rem', display: 'block'}}>{errors.userId}</span>}
            </div>
            <div className="form-group">
              <label>이메일</label>
              <input 
                type="email" 
                name="email"
                placeholder="이메일을 입력하세요" 
                value={formData.email}
                onChange={handleChange}
                required 
              />
              {errors.email && <span style={{color: 'var(--error)', fontSize: '0.85rem', marginTop: '0.25rem', display: 'block'}}>{errors.email}</span>}
            </div>
            <div className="form-group">
              <label>비밀번호</label>
              <input 
                type="password" 
                name="password"
                placeholder="비밀번호를 입력하세요 (최소 6자)" 
                value={formData.password}
                onChange={handleChange}
                required 
              />
              {errors.password && <span style={{color: 'var(--error)', fontSize: '0.85rem', marginTop: '0.25rem', display: 'block'}}>{errors.password}</span>}
            </div>
            <div className="form-group">
              <label>비밀번호 확인</label>
              <input 
                type="password" 
                name="passwordConfirm"
                placeholder="비밀번호를 다시 입력하세요" 
                value={formData.passwordConfirm}
                onChange={handleChange}
                required 
              />
              {errors.passwordConfirm && <span style={{color: 'var(--error)', fontSize: '0.85rem', marginTop: '0.25rem', display: 'block'}}>{errors.passwordConfirm}</span>}
            </div>
            <div className="form-actions">
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? '처리 중...' : '가입하기'}
              </button>
              <Link to="/" className="btn btn-secondary" style={{textDecoration: 'none', textAlign: 'center'}}>취소</Link>
            </div>
          </form>
          <div className="form-link">
            이미 계정이 있으신가요? <Link to="/login">로그인</Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Register;

