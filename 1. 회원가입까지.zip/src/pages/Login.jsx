import { useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header.jsx';

function Login() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (userId && password) {
      alert(`로그인 되었습니다: ${userId}`);
      // 실제 로그인 로직은 여기에 구현 (Spring 백엔드 API 연동)
    }
  };

  return (
    <>
      <Header />
      <div className="container">
        <div className="form-card">
          <h2>로그인</h2>
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>아이디</label>
              <input 
                type="text" 
                placeholder="사용자 아이디를 입력하세요" 
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                required 
              />
            </div>
            <div className="form-group">
              <label>비밀번호</label>
              <input 
                type="password" 
                placeholder="비밀번호를 입력하세요" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required 
              />
            </div>
            <div className="form-actions">
              <button type="submit" className="btn btn-primary">로그인</button>
            </div>
          </form>
          <div className="form-link">
            <Link to="/find-id">아이디 찾기</Link> | 
            <Link to="/find-password"> 비밀번호 찾기</Link>
          </div>
          <div className="form-link">
            계정이 없으신가요? <Link to="/register">회원가입</Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;

