import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080';

// Axios 인스턴스 생성
const memberApi = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 회원가입 요청
export const registerMember = async (registerData) => {
  const response = await memberApi.post('/member/register', {
    userId: registerData.userId,
    userName: registerData.userName,
    email: registerData.email,
    password: registerData.password,
    passwordCheck: registerData.passwordCheck,
  });
  return response.data;
};

export default memberApi;

