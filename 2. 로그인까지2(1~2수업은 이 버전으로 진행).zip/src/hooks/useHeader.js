import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import useUserStore from '../store/userStore';
import { useLoginStatus } from '../query/useMemberQueries';

export const useHeader = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { logout } = useUserStore();

  // API를 통해 현재 로그인 상태 확인
  const { data: currentUser, isLoading, isError } = useLoginStatus();

  const handleLogout = () => {
    logout();
    // 쿼리 캐시 무효화하여 로그인 상태 재확인
    queryClient.invalidateQueries({ queryKey: ['loginStatus'] });
    navigate('/');
  };

  // 로딩 중이거나 에러가 발생한 경우, 또는 currentUser가 null인 경우 로그인 안 된 상태로 처리
  const isLoggedIn = !isLoading && !isError && currentUser;

  return {
    currentUser,
    isLoading,
    isLoggedIn,
    handleLogout,
  };
};

