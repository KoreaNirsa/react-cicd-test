import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080';

// Axios 인스턴스 생성
const boardApi = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 공지사항 목록 조회 (페이징 포함)
export const getNoticeList = async (page = 1) => {
  const response = await boardApi.get('/board/notice', {
    params: {
      page: page,
    },
    withCredentials: true, // 세션 쿠키를 포함하기 위해 필요
  });
  return response.data;
};

export default boardApi;

