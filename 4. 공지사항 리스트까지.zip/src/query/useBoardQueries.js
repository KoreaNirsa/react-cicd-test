import { useQuery } from '@tanstack/react-query';
import { getNoticeList } from '../api/boardApi';

// 공지사항 목록 조회 Query
export const useNoticeList = (page = 1) => {
  return useQuery({
    queryKey: ['noticeList', page],
    queryFn: () => getNoticeList(page),
    staleTime: 30000, // 30초간 캐시 유지
    retry: 1,
  });
};

