import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import Header from '../components/Header.jsx';
import useUserStore from '../store/userStore';
import { loginMember } from '../api/memberApi';

function Login() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { setCurrentUser } = useUserStore();
  
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // TanStack Query Mutation
  const loginMutation = useMutation({
    mutationFn: loginMember,
    onSuccess: (data) => {
      // 백엔드에서 반환한 사용자 정보를 store에 저장
      setCurrentUser(data);
      // 로그인 상태 확인 쿼리 캐시 무효화하여 Header가 최신 상태 확인
      queryClient.invalidateQueries({ queryKey: ['loginStatus'] });
      alert(`로그인 되었습니다: ${data.userName || data.userId}`);
      navigate('/');
    },
    onError: (error) => {
      if (error.response) {
        // 서버에서 반환한 에러 메시지 처리
        const errorMessage = error.response.data?.message || 
                           error.response.data?.errorMsg || 
                           '아이디 또는 비밀번호가 올바르지 않습니다.';
        setError(errorMessage);
      } else if (error.request) {
        // 요청은 보냈지만 응답을 받지 못한 경우
        setError('서버에 연결할 수 없습니다. 서버가 실행 중인지 확인해주세요.');
      } else {
        // 요청 설정 중 에러 발생
        setError('로그인 요청 중 오류가 발생했습니다.');
      }
    },
  });

  const handleLogin = (e) => {
    e.preventDefault();
    setError(''); // 에러 초기화
    
    if (!userId.trim()) {
      setError('아이디를 입력하세요.');
      return;
    }
    
    if (!password) {
      setError('비밀번호를 입력하세요.');
      return;
    }

    // 로그인 요청
    loginMutation.mutate({
      userId: userId.trim(),
      password: password,
    });
  };

  return (
    <>
      <Header />
      <div className="container">
        <div className="form-card">
          <h2>로그인</h2>
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>아이디</label>
              <input 
                type="text" 
                placeholder="사용자 아이디를 입력하세요" 
                value={userId}
                onChange={(e) => {
                  setUserId(e.target.value);
                  setError(''); // 입력 시 에러 초기화
                }}
                required 
              />
            </div>
            <div className="form-group">
              <label>비밀번호</label>
              <input 
                type="password" 
                placeholder="비밀번호를 입력하세요" 
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(''); // 입력 시 에러 초기화
                }}
                required 
              />
            </div>
            {error && (
              <div style={{color: 'var(--error)', fontSize: '0.9rem', marginBottom: '1rem', textAlign: 'center'}}>
                {error}
              </div>
            )}
            <div className="form-actions">
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? '로그인 중...' : '로그인'}
              </button>
            </div>
          </form>
          <div className="form-link">
            <Link to="/find-id">아이디 찾기</Link> | 
            <Link to="/find-password"> 비밀번호 찾기</Link>
          </div>
          <div className="form-link">
            계정이 없으신가요? <Link to="/register">회원가입</Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;

